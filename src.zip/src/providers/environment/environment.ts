export const environmentVariable = {
    settings : {
    "floor-check-service" :  "https://floorchecks.com:8443/floorcheck-2.0/api/"
    }
}