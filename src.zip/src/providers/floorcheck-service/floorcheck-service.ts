import { environmentVariable } from './../environment/environment';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

/*
  Generated class for the FloorcheckServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class FloorcheckServiceProvider {
  floorcheckData = [];
  constructor(public http: HttpClient) {}

  getCurrentFloorcheckData() {
    return this.floorcheckData;
  }

  setCurrentFloorcheckData(value) {
    this.floorcheckData.unshift(value);
  }

  updateFloorCheckStatus(uniqueId, status) {
    const index = this.floorcheckData.findIndex(
      result => result.uniqueId === uniqueId
    );
    if (index > -1) {
      this.floorcheckData[index].status = status;
    }
  }

  getAssets() {
    return this.http.get(
      environmentVariable.settings['floor-check-service'] + 'asset/findAll'
    );
  }

  getAssetsById(assetid) {
    return this.http.get(
      environmentVariable.settings['floor-check-service'] +
        'asset/assetid/' +
        assetid
    );
  }
}
