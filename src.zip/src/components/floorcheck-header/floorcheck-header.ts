import { Component, Input } from '@angular/core';
import { PopoverController } from 'ionic-angular';
import { PopoverPage } from '../../pages/popover/popover';

/**
 * Generated class for the FloorcheckHeaderComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'floorcheck-header',
  templateUrl: 'floorcheck-header.html'
})
export class FloorcheckHeaderComponent {
  @Input() header: string;
  constructor(private popoverCtrl: PopoverController) {}

  presentPopover(myEvent) {
    const popover = this.popoverCtrl.create(PopoverPage);
    popover.present({
      ev: myEvent
    });
  }
}
