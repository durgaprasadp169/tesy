import { NgModule } from '@angular/core';
import { IonicModule } from 'ionic-angular';
import { FloorcheckHeaderComponent } from './floorcheck-header';

@NgModule({
  declarations: [FloorcheckHeaderComponent],
  imports: [IonicModule],
  exports: [FloorcheckHeaderComponent]
})
export class FloorcheckHearderModule {}
