import { NgModule } from '@angular/core';
import { FloorcheckHeaderComponent } from './floorcheck-header/floorcheck-header';
import { IonicModule, IonicPageModule } from 'ionic-angular';

@NgModule({
	// declarations: [FloorcheckHeaderComponent,
    // FloorcheckHeaderComponent],
	imports: [IonicPageModule.forChild(FloorcheckHeaderComponent)],
	// exports: [FloorcheckHeaderComponent,
    // FloorcheckHeaderComponent]
})
export class ComponentsModule {}
