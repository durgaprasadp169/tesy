import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ReviewPage } from './review';
import { FloorcheckHearderModule } from '../../components/floorcheck-header/floorcheck-header.module';

@NgModule({
  declarations: [
    ReviewPage,
  ],
  imports: [
    IonicPageModule.forChild(ReviewPage),
    FloorcheckHearderModule
  ],
})
export class ReviewPageModule {}
