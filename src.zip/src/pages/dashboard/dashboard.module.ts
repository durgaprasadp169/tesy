import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DashboardPage } from './dashboard';
import { FloorcheckHearderModule } from '../../components/floorcheck-header/floorcheck-header.module';

@NgModule({
  declarations: [
    DashboardPage,
  ],
  imports: [
    IonicPageModule.forChild(DashboardPage),
    FloorcheckHearderModule
  ],
})
export class DashboardPageModule {}
