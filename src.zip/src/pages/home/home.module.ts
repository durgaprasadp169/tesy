import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HomePage } from './home';
import { FloorcheckHearderModule } from '../../components/floorcheck-header/floorcheck-header.module';

@NgModule({
  declarations: [
    HomePage,
  ],
  imports: [
    IonicPageModule.forChild(HomePage),
    FloorcheckHearderModule
  ],
})
export class HomePageModule {}
