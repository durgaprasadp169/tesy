import { FloorcheckServiceProvider } from './../../providers/floorcheck-service/floorcheck-service';
import { Component } from '@angular/core';
import {
  IonicPage,
  NavController,
  NavParams,
  ToastController,
  LoadingController
} from 'ionic-angular';
import { environmentVariable } from '../../providers/environment/environment';
import { HttpClient } from '@angular/common/http';
import { Diagnostic } from '@ionic-native/diagnostic';
import {
  NativeGeocoder,
  NativeGeocoderReverseResult
} from '@ionic-native/native-geocoder';
import {
  FileTransfer,
  FileUploadOptions,
  FileTransferObject
} from '@ionic-native/file-transfer';
import { MediaCapture, MediaFile } from '@ionic-native/media-capture';
import { Geolocation } from '@ionic-native/geolocation';

/**
 * Generated class for the AddPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-add',
  templateUrl: 'add.html'
})
export class AddPage {
  isPageLoadingInProgress;
  asset;
  locationDetails: any = {};
  public base64Image: string;
  public isLocationEnabled: boolean = false;
  public latitude: any;
  public longitude: any;
  public geoResult: any;
  public currentDateTime: string;
  secondconfirmation: boolean = false;
  assettype;
  assetId;
  uploadProgressMesg;
  headerMessage;
  uploadingProgress;
  header;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private diagnostic: Diagnostic,
    private geolocation: Geolocation,
    public toastCtrl: ToastController,
    private nativeGeocoder: NativeGeocoder,
    private mediaCapture: MediaCapture,
    private transfer: FileTransfer,
    private loadingCtrl: LoadingController,
    private httpClient: HttpClient,
    private floorCheckService: FloorcheckServiceProvider
  ) {
    this.assetId = navParams.get('assetid');
    this.headerMessage = 'Upload video';
    this.header = 'Add new object';

    if (this.assetId) {
      this.showLoading();
      this.getAssetById();
    }
  }

  ionViewDidLoad() {}

  getAssetById() {
    this.floorCheckService.getAssetsById(this.assetId).subscribe(
      result => {
        this.asset = result;
        this.headerMessage = 'Scan ' + this.asset.assettype + ' for review';
        this.assettype = this.asset.assettype;
        this.header =
          'Review ' + this.assettype + ' - ' + 'Asset Id : ' + this.assetId;

        this.hideLoading();
      },
      error => {
        const videoUploadErrorMsg = this.toastCtrl.create({
          message: JSON.stringify(error), // "Video uploaded failed. Please try again later.",
          duration: 5000,
          position: 'top'
        });
        videoUploadErrorMsg.present();
        this.hideLoading();
      }
    );
  }

  isLocationAvailable(currentDateTime) {
    // this.locationDetails = {};
    this.diagnostic
      .isLocationAvailable()
      .then(isAvailable => {
        this.geolocation
          .getCurrentPosition()
          .then((data: any) => {
            this.isLocationEnabled = true;
            this.latitude = data.coords.latitude;
            this.longitude = data.coords.longitude;
            this.locationDetails.dateobj = currentDateTime;

            this.nativeGeocoder
              .reverseGeocode(this.latitude, this.longitude)
              .then((result: NativeGeocoderReverseResult[]) => {
                this.locationDetails.geo = result[0];
                this.uploadVideo();
              })
              .catch((error: any) => {
                this.hideLoading();
                this.uploadingProgress = 'failed';
              });
          })
          .catch((error: any) => {
            let errolocation = this.toastCtrl.create({
              message: 'Could not get the location.',
              duration: 5000,
              position: 'top'
            });
            errolocation.present();
            this.uploadProgressMesg = undefined;
            this.hideLoading();
            this.uploadingProgress = 'failed';
          });
      })
      .catch((error: any) => {
        let locationis = this.toastCtrl.create({
          message: 'Location not enabled. Please enable location to continue',
          duration: 5000,
          position: 'top'
        });
        locationis.present();
        this.uploadProgressMesg = undefined;
        this.hideLoading();
        this.uploadingProgress = 'failed';
      });
  }

  takePicture() {
    this.asset = undefined;
    this.uploadProgressMesg =
      this.assettype + ' detection in progress. Please wait...';
    this.uploadingProgress = 'inprogress';
    const currentDateTime = new Date().toISOString();
    this.isLocationAvailable(currentDateTime);
    // this.hideLoading();
  }

  uploadVideo() {
    const uniqueId = (((1 + Math.random()) * 0x10000) | 0)
      .toString(16)
      .substring(1);
    const floorcheckData = {
      uniqueId: uniqueId,
      assetType: this.assettype,
      status: 'In Progress'
    };
    this.floorCheckService.setCurrentFloorcheckData(floorcheckData);
    const floorcheckArray = this.floorCheckService.getCurrentFloorcheckData();
    this.mediaCapture.captureVideo().then(
      (data: MediaFile[]) => {
        this.asset = undefined;
        this.diagnostic
          .requestExternalStorageAuthorization()
          .then(() => {
            this.showLoading();
            //User gave permission
            const options: FileUploadOptions = {
              fileKey: 'file',
              chunkedMode: false,
              mimeType: 'mulitpart/form-data',
              headers: {
                'Content-Type': undefined
              },
              fileName: data[0].name
            };

            this.hideLoading();

            if (this.locationDetails && this.locationDetails.geo) {
              const fileTransfer: FileTransferObject = this.transfer.create();
              const uploadUrl = isNaN(this.assetId)
                ? 'asset/uploadvideo?assetType=' +
                  this.assettype +
                  '&City=' +
                  this.locationDetails.geo.locality +
                  '&location=' +
                  this.locationDetails.geo.locality +
                  '&country=' +
                  this.locationDetails.geo.countryName
                : 'asset/reviewvideo/assetid/' +
                  this.assetId +
                  '?assetType=' +
                  this.assettype;
              fileTransfer
                .upload(
                  data[0].fullPath,
                  environmentVariable.settings['floor-check-service'] +
                    uploadUrl,
                  options
                )
                .then(
                  success => {
                    const videoUploadSuccessMsg = this.toastCtrl.create({
                      message: 'Video uploaded successfully.',
                      duration: 5000,
                      position: 'top'
                    });
                    videoUploadSuccessMsg.present();
                    this.uploadProgressMesg = undefined;
                    this.asset = JSON.parse(success.response);
                    this.uploadingProgress = 'success';

                    this.floorCheckService.updateFloorCheckStatus(
                      uniqueId,
                      'Success'
                    );
                    if (this.asset.lateststatus != 'Success') {
                      this.uploadProgressMesg =
                        this.assettype +
                        ' detection failed. Please try again later.';
                      this.asset = undefined;
                      this.uploadingProgress = 'failed';
                      this.floorCheckService.updateFloorCheckStatus(
                        uniqueId,
                        'Failed'
                      );
                    }
                  },
                  error => {
                    this.uploadProgressMesg =
                      this.assettype +
                      'detection failed. Please try again later.';
                    const videoUploadErrorMsg = this.toastCtrl.create({
                      message: JSON.stringify(error), // "Video uploaded failed. Please try again later.",
                      duration: 5000,
                      position: 'top'
                    });
                    videoUploadErrorMsg.present();
                    this.uploadingProgress = 'failed';
                    this.floorCheckService.updateFloorCheckStatus(
                      uniqueId,
                      'Failed'
                    );
                  }
                );
            }
          })
          .catch(error => {
            //Handle error
          });
      },

      err => {}
    );
  }

  showLoading() {
    if (!this.isPageLoadingInProgress) {
      this.isPageLoadingInProgress = this.loadingCtrl.create({
        content: 'Video upload is in progress. Please wait...'
      });
      this.isPageLoadingInProgress.present();
    }
  }

  hideLoading() {
    if (this.isPageLoadingInProgress) {
      this.isPageLoadingInProgress.dismiss();
      this.isPageLoadingInProgress = undefined;
    }
  }
}
