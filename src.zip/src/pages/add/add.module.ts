import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddPage } from './add';
import { FloorcheckHearderModule } from '../../components/floorcheck-header/floorcheck-header.module';

@NgModule({
  declarations: [
    AddPage,
  ],
  imports: [
    IonicPageModule.forChild(AddPage),
    FloorcheckHearderModule
  ],
})
export class AddPageModule {}
