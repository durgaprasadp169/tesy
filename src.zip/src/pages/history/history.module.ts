import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HistoryPage } from './history';
import { FloorcheckHearderModule } from '../../components/floorcheck-header/floorcheck-header.module';

@NgModule({
  declarations: [
    HistoryPage,
  ],
  imports: [
    IonicPageModule.forChild(HistoryPage),
    FloorcheckHearderModule
  ],
})
export class HistoryPageModule {}
