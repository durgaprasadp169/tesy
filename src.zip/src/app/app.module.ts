import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule, CUSTOM_ELEMENTS_SCHEMA,APP_INITIALIZER } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { ListPage } from '../pages/list/list';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { PopoverPage } from '../pages/popover/popover';
import { PopoverPageModule } from '../pages/popover/popover.module';
import { HomePageModule } from '../pages/home/home.module';
import { AddPageModule } from '../pages/add/add.module';
import { ReviewPageModule } from '../pages/review/review.module';
import { DashboardPageModule } from '../pages/dashboard/dashboard.module';
import { FloorcheckServiceProvider } from '../providers/floorcheck-service/floorcheck-service';
import { Diagnostic } from '@ionic-native/diagnostic';
import { Geolocation } from '@ionic-native/geolocation';
import { FileTransfer } from '@ionic-native/file-transfer';
import { NativeGeocoder } from '@ionic-native/native-geocoder';
import { MediaCapture } from '@ionic-native/media-capture';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule, Http } from '@angular/http';
import { HistoryPageModule } from '../pages/history/history.module';
import {  KeycloakAngularModule } from '../keycloak-angular/src/lib/keycloak-angular.module';
import { KeycloakService } from '../keycloak-angular/src/lib/core/services/keycloak.service';

import { initializer } from './app-init';


@NgModule({
  declarations: [MyApp, ListPage],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    PopoverPageModule,
    HomePageModule,
    AddPageModule,
    ReviewPageModule,
    DashboardPageModule,
    HistoryPageModule,
    HttpModule,
    HttpClientModule,
	KeycloakAngularModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [MyApp, HomePage, ListPage],
  providers: [
    StatusBar,
    SplashScreen,
    { provide: ErrorHandler, useClass: IonicErrorHandler },
	{
      provide: APP_INITIALIZER,
      useFactory: initializer,
      multi: true,
      deps: [KeycloakService]
    },
    FloorcheckServiceProvider,
    Diagnostic,
    Geolocation,
    FileTransfer,
    NativeGeocoder,
    MediaCapture,
    HttpClientModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule {}
